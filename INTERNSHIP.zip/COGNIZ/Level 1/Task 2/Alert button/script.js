let currentTime = new Date().getHours();

if (currentTime < 12) {
	alert('Good morning!');
} else if (currentTime < 17) {
	alert('Good afternoon!');
} else {
	alert('Good evening!');
}