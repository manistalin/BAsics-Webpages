let num1Input = document.getElementById('num1');
let num2Input = document.getElementById('num2');
let addButton = document.getElementById('addButton');
let resultParagraph = document.getElementById('result');

addButton.addEventListener('click', function() {
	let num1 = parseFloat(num1Input.value);
	let num2 = parseFloat(num2Input.value);
	let result = num1 + num2;
	resultParagraph.textContent = `The result is: ${result}`;
});